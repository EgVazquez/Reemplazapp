function mensajeEnProceso(){
    swal('Su postulacion se encuentra aprobada\n', "Estado: en proceso",'success');
}

function mensajeSeleccionado(){
    swal("Su postulacion se encuentra aprobada\n", "Estado: Seleccionado/a", 'success');
}

function mensajePostulacionRechazada(){
    swal("Su postulacion se encuentra rechazada\n", "Estado: Rechazada" , 'error');
}